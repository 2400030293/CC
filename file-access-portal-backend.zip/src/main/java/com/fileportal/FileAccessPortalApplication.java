package com.fileportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileAccessPortalApplication {
    public static void main(String[] args) {
        SpringApplication.run(FileAccessPortalApplication.class, args);
    }
}
