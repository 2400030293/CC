package com.fileportal.controller;

import com.fileportal.dto.FileDto;
import com.fileportal.model.FileEntity;
import com.fileportal.model.Role;
import com.fileportal.repository.FileRepository;
import com.fileportal.service.FileStorageService;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/files")
public class FileController {

    private final FileRepository fileRepository;
    private final FileStorageService storageService;

    public FileController(FileRepository fileRepository, FileStorageService storageService) {
        this.fileRepository = fileRepository;
        this.storageService = storageService;
    }

    @GetMapping
    public List<FileDto> listVisible(Authentication authentication) {
        Role role = currentRole(authentication);

        // Admins see everything; everyone else sees only files their role is permitted for.
        List<FileEntity> files = (role == Role.ADMIN)
                ? fileRepository.findAllByOrderByCreatedAtDesc()
                : fileRepository.findVisibleToRole(role);

        return files.stream().map(FileDto::from).collect(Collectors.toList());
    }

    @GetMapping("/{id}/download")
    public ResponseEntity<?> download(@PathVariable Long id, Authentication authentication) {
        FileEntity entity = fileRepository.findById(id).orElse(null);
        if (entity == null) {
            return ResponseEntity.status(404).body(Map.of("error", "File not found"));
        }

        Role role = currentRole(authentication);
        boolean allowed = (role == Role.ADMIN) || entity.getAllowedRoles().contains(role);
        if (!allowed) {
            return ResponseEntity.status(403).body(Map.of("error", "You do not have access to this file"));
        }

        try {
            InputStreamResource resource = new InputStreamResource(storageService.load(entity.getStoredName()));
            ContentDisposition disposition = ContentDisposition.attachment()
                    .filename(entity.getOriginalName())
                    .build();

            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, disposition.toString())
                    .body(resource);

        } catch (IOException e) {
            return ResponseEntity.status(500).body(Map.of("error", "Failed to read file"));
        }
    }

    private Role currentRole(Authentication authentication) {
        String authority = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .findFirst()
                .orElse("ROLE_HR");
        return Role.valueOf(authority.replace("ROLE_", ""));
    }
}
