package com.fileportal.controller;

import com.fileportal.dto.FileDto;
import com.fileportal.dto.PermissionUpdateRequest;
import com.fileportal.model.FileEntity;
import com.fileportal.model.Role;
import com.fileportal.repository.FileRepository;
import com.fileportal.service.FileStorageService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin/files")
public class AdminFileController {

    private final FileRepository fileRepository;
    private final FileStorageService storageService;

    public AdminFileController(FileRepository fileRepository, FileStorageService storageService) {
        this.fileRepository = fileRepository;
        this.storageService = storageService;
    }

    @PostMapping
    public ResponseEntity<?> upload(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "roles", required = false) List<String> roles,
            Authentication authentication
    ) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "No file provided"));
        }

        try {
            String storedName = storageService.store(file);

            FileEntity entity = new FileEntity();
            entity.setOriginalName(file.getOriginalFilename());
            entity.setStoredName(storedName);
            entity.setSizeBytes(file.getSize());
            entity.setUploadedBy(authentication.getName());
            entity.setAllowedRoles(parseRoles(roles));

            fileRepository.save(entity);
            return ResponseEntity.ok(FileDto.from(entity));

        } catch (IOException e) {
            return ResponseEntity.status(500).body(Map.of("error", "Failed to store file: " + e.getMessage()));
        }
    }

    @GetMapping
    public List<FileDto> listAll() {
        return fileRepository.findAllByOrderByCreatedAtDesc()
                .stream().map(FileDto::from).collect(Collectors.toList());
    }

    @PutMapping("/{id}/permissions")
    public ResponseEntity<?> updatePermissions(@PathVariable Long id, @RequestBody PermissionUpdateRequest request) {
        FileEntity entity = fileRepository.findById(id).orElse(null);
        if (entity == null) {
            return ResponseEntity.status(404).body(Map.of("error", "File not found"));
        }

        entity.setAllowedRoles(parseRoles(request.getRoles()));
        fileRepository.save(entity);
        return ResponseEntity.ok(FileDto.from(entity));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        FileEntity entity = fileRepository.findById(id).orElse(null);
        if (entity == null) {
            return ResponseEntity.status(404).body(Map.of("error", "File not found"));
        }

        try {
            storageService.delete(entity.getStoredName());
        } catch (IOException e) {
            // Continue deleting the DB record even if the physical file was already gone
        }
        fileRepository.delete(entity);
        return ResponseEntity.ok(Map.of("deleted", true));
    }

    private Set<Role> parseRoles(List<String> roles) {
        Set<Role> result = new HashSet<>();
        if (roles == null) return result;
        for (String r : roles) {
            try {
                result.add(Role.valueOf(r.trim().toUpperCase()));
            } catch (IllegalArgumentException ignored) {
                // silently skip unrecognized role names rather than failing the whole request
            }
        }
        result.remove(Role.ADMIN); // admin always has access implicitly; never stored explicitly
        return result;
    }
}
