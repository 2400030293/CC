package com.fileportal.repository;

import com.fileportal.model.FileEntity;
import com.fileportal.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FileRepository extends JpaRepository<FileEntity, Long> {

    @Query("SELECT DISTINCT f FROM FileEntity f JOIN f.allowedRoles r WHERE r = :role ORDER BY f.createdAt DESC")
    List<FileEntity> findVisibleToRole(@Param("role") Role role);

    List<FileEntity> findAllByOrderByCreatedAtDesc();
}
