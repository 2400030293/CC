package com.fileportal.model;

public enum Role {
    ADMIN,
    HR,
    INTERN,
    FINANCE,
    MANAGER
}
