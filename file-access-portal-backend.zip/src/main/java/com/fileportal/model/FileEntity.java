package com.fileportal.model;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "files")
public class FileEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String originalName;

    // Randomized name actually used on disk, so two uploads with the same
    // original filename never collide and users can't guess each other's paths.
    @Column(nullable = false, unique = true)
    private String storedName;

    @Column(nullable = false)
    private long sizeBytes;

    @Column(nullable = false)
    private String uploadedBy;

    @Column(nullable = false)
    private Instant createdAt = Instant.now();

    // Which roles are allowed to see/download this file.
    // ADMIN is implicitly always allowed and is not stored here.
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "file_permissions", joinColumns = @JoinColumn(name = "file_id"))
    @Column(name = "role")
    @Enumerated(EnumType.STRING)
    private Set<Role> allowedRoles = new HashSet<>();

    public FileEntity() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getOriginalName() { return originalName; }
    public void setOriginalName(String originalName) { this.originalName = originalName; }

    public String getStoredName() { return storedName; }
    public void setStoredName(String storedName) { this.storedName = storedName; }

    public long getSizeBytes() { return sizeBytes; }
    public void setSizeBytes(long sizeBytes) { this.sizeBytes = sizeBytes; }

    public String getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(String uploadedBy) { this.uploadedBy = uploadedBy; }

    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }

    public Set<Role> getAllowedRoles() { return allowedRoles; }
    public void setAllowedRoles(Set<Role> allowedRoles) { this.allowedRoles = allowedRoles; }
}
