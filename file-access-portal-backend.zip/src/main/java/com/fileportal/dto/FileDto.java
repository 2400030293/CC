package com.fileportal.dto;

import com.fileportal.model.FileEntity;

import java.time.Instant;
import java.util.Set;
import java.util.stream.Collectors;

public class FileDto {
    private Long id;
    private String originalName;
    private long sizeBytes;
    private String uploadedBy;
    private Instant createdAt;
    private Set<String> allowedRoles;

    public static FileDto from(FileEntity f) {
        FileDto dto = new FileDto();
        dto.id = f.getId();
        dto.originalName = f.getOriginalName();
        dto.sizeBytes = f.getSizeBytes();
        dto.uploadedBy = f.getUploadedBy();
        dto.createdAt = f.getCreatedAt();
        dto.allowedRoles = f.getAllowedRoles().stream().map(Enum::name).collect(Collectors.toSet());
        return dto;
    }

    public Long getId() { return id; }
    public String getOriginalName() { return originalName; }
    public long getSizeBytes() { return sizeBytes; }
    public String getUploadedBy() { return uploadedBy; }
    public Instant getCreatedAt() { return createdAt; }
    public Set<String> getAllowedRoles() { return allowedRoles; }
}
