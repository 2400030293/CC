package com.fileportal.dto;

import java.util.List;

public class PermissionUpdateRequest {
    // e.g. ["HR", "MANAGER"]
    private List<String> roles;

    public List<String> getRoles() { return roles; }
    public void setRoles(List<String> roles) { this.roles = roles; }
}
