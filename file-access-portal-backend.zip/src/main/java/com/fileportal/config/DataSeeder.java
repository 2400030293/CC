package com.fileportal.config;

import com.fileportal.model.Role;
import com.fileportal.model.User;
import com.fileportal.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataSeeder(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        seed("admin", "Admin@123", Role.ADMIN);
        seed("hr1", "Hr@12345", Role.HR);
        seed("intern1", "Intern@123", Role.INTERN);
        seed("finance1", "Finance@123", Role.FINANCE);
        seed("manager1", "Manager@123", Role.MANAGER);
    }

    private void seed(String username, String rawPassword, Role role) {
        if (userRepository.existsByUsername(username)) {
            return;
        }
        User user = new User(username, passwordEncoder.encode(rawPassword), role);
        userRepository.save(user);
        System.out.println("Seeded user: " + username + " / " + rawPassword + " (" + role + ")");
    }
}
