# File Access Portal — Backend (Spring Boot)

Role-based file access API: admin uploads files and picks which roles
(HR, Intern, Finance, Manager) can see each one.

## Open in Spring Tool Suite
1. File → Import → Maven → Existing Maven Projects
2. Browse to this `backend` folder, select it, Finish
3. Wait for Maven to download dependencies (needs internet the first time)
4. Right-click `FileAccessPortalApplication.java` → Run As → Spring Boot App

Runs on **http://localhost:8080**. On first startup it seeds one login per role
(printed in the console) and creates a local `data/appdb.mv.db` (H2 file database)
and `uploads/` folder — no external database server needed.

## Seeded logins
| Username  | Password      | Role    |
|-----------|---------------|---------|
| admin     | Admin@123     | ADMIN   |
| hr1       | Hr@12345      | HR      |
| intern1   | Intern@123    | INTERN  |
| finance1  | Finance@123   | FINANCE |
| manager1  | Manager@123   | MANAGER |

## API
- `POST /api/auth/login` → `{ token, username, role }`
- `POST /api/admin/files` (admin) — multipart: `file`, repeated `roles` fields
- `GET /api/admin/files` (admin) — all files + their permissions
- `PUT /api/admin/files/{id}/permissions` (admin) — body `{ "roles": ["HR","MANAGER"] }`
- `DELETE /api/admin/files/{id}` (admin)
- `GET /api/files` (any logged-in user) — files visible to your role
- `GET /api/files/{id}/download` (any logged-in user, permission-checked)

All non-login endpoints require `Authorization: Bearer <token>`.

## CORS
Allowed frontend origins are set in `src/main/resources/application.properties`
under `app.cors.allowed-origins` — defaults cover VS Code's Live Server (port
5500/5501) and localhost:3000. Add your own if you serve the frontend
differently.

## Command line (without an IDE)
```bash
mvn spring-boot:run
```
